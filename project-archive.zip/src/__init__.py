"""AI-Powered Customer Support System - MVP"""

__version__ = "0.1.0"
